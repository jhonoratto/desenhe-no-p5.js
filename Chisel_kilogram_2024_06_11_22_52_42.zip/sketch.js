function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
function setup() {

createCanvas(600, 600);

background("black");

}

function draw() {

stroke("#7C5FB1");

fill("red");

if(mouseIsPressed){

ellipse(mouseX, mouseY,20, 35);

}

}

